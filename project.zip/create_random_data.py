import csv
import random
import os

"""
Generates a csv file with random data .
"""


def create_random_row(size):
    """
    :param size:int -> Size of the array to return
    :return: list -> A random list of size elements containing numbers between 1 to 10000
    """
    return [random.randrange(1, 10001) for i in range(size)]


def create_csv_file(name):
    """
    Generated a csv file with random numberds with each row having numbers between 1 and 10000.
    Each next row has 100 more numbers then the previous one starting with 250 numbers in first row.
    :param name: str -> Name of the csv file where randomly generated data will be written
    """
    # Creates a 2D list with random generated data
    data = [create_random_row(250 + i * 100) for i in range(200)]
    with open(name, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(data)  # Writes the data to the csv file
    print(f"Data written to {name}")


def main():
    """
    Prompts the user the name of the file the data will be written to then writes the data to the file,
    """
    while True:
        name = input("Enter the filename to save the data to :")
        if os.path.exists(name):  # If the file already exists
            # Give an option to overwrite the file if exists
            choice = input("The file already exits . Do you want to overwrite (y/n) : ")
            if choice in ("Y", "y", "Yes", "yes"):
                break
        else:
            break

    create_csv_file(name)  # Writes the data to the csv file name


if __name__ == '__main__':
    main()

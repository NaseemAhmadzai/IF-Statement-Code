def bubbleSort(array) -> list:
    """
    :param array: list -> Unsorted Array
    :return: list -> Sorted Array
    Takes input an array and sorts it via bubble sort algorithm then returns a sorted array
    """
    n = len(array)
    # Traverse through all array elements
    for i in range(n - 1):
        # Traverse the array from 0 to n-i-1
        for j in range(0, n - i - 1):
            # Swap if the element found is greater
            if array[j] > array[j + 1]:
                # Swaps the elements
                array[j], array[j + 1] = array[j + 1], array[j]
    return array


def insertionSort(arr):
    """
    :param array: list -> Unsorted Array
    :return: list -> Sorted Array
    Takes input an array and sorts it via insertion sort algorithm then returns a sorted array
    """
    # Traverse through 1 to length of the array
    for i in range(1, len(arr)):
        key = arr[i]
        # Move elements of arr[0..i-1], that are
        # greater than key, to one position ahead
        # of their current position
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr


def merge(arr, l, m, r):
    """

    :param arr : list -> Array to merge:
    :param l : int -> Left Index
    :param m: int -> Middle element that divides the array
    :param r: int -> Right Index
    :return: list -> Merged Array

    It takes input an array , left , middle and right index . Divides the array using indexes then merges them.
    """
    n1 = m - l + 1
    n2 = r - m

    # create temp arrays
    L = [0] * (n1)
    R = [0] * (n2)

    # Copy data to temp arrays L[] and R[]
    for i in range(0, n1):
        L[i] = arr[l + i]

    for j in range(0, n2):
        R[j] = arr[m + 1 + j]

    # Merge the temp arrays back into arr[l..r]
    i = 0  # Initial index of first subarray
    j = 0  # Initial index of second subarray
    k = l  # Initial index of merged subarray

    while i < n1 and j < n2:
        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1

    # Copy the remaining elements of L[], if there
    # are any
    while i < n1:
        arr[k] = L[i]
        i += 1
        k += 1

    # Copy the remaining elements of R[], if there
    # are any
    while j < n2:
        arr[k] = R[j]
        j += 1
        k += 1
    return arr


def _mergeSort(arr, l, r):
    """

    :param arr:
    :param l:
    :param r:
    :return:
    """
    if l < r:
        # Same as (l+r)//2, but avoids overflow for
        # large l and h
        m = l + (r - l) // 2

        # Sort first and second halves
        _mergeSort(arr, l, m)
        _mergeSort(arr, m + 1, r)
        merge(arr, l, m, r)
    return arr


def mergesort(arr):
    """
    :param arr:
    :return list-> Sorted Array:
    """
    return _mergeSort(arr, 0, len(arr) - 1)


def partition(l, r, nums):
    # Last element will be the pivot and the first element the pointer
    pivot, ptr = nums[r], l
    for i in range(l, r):
        if nums[i] <= pivot:
            # Swapping values smaller than the pivot to the front
            nums[i], nums[ptr] = nums[ptr], nums[i]
            ptr += 1
    # Finally swapping the last element with the pointer indexed number
    nums[ptr], nums[r] = nums[r], nums[ptr]
    return ptr


def _quicksort(l, r, nums):
    """
    Takes input the left index,right index , unsorted array and returns the sorted array using quicksort algorithm
    :param l : int -> Left Index
    :param r: int -> Right index
    :param nums: list -> Unsorted array
    :return:
    """

    if len(nums) == 1:  # Terminating Condition for recursion. VERY IMPORTANT!
        return nums
    if l < r:
        pi = partition(l, r, nums)
        _quicksort(l, pi - 1, nums)  # Recursively sorting the left values
        _quicksort(pi + 1, r, nums)  # Recursively sorting the right values
    return nums


def quicksort(arr):
    return _quicksort(0, len(arr) - 1, arr)

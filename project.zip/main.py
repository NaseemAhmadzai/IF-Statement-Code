import csv
import os
import time
from algos import bubbleSort, insertionSort, mergesort, quicksort


# Importing all the sorting algorithms

def choose_algo() -> int:
    """
    Shows the Algorithm choice menu returns an integer between 1 to 4.
    1 = Bubble Sort
    2 = Insertion Sort
    3 = Merge Sort
    4 = Quick Sort
    """
    print("Please Choose one of the sorting algorithms to run .\n"
          "1) Bubble Sort\n"
          "2) Insertion SOrt\n"
          "3) Merge Sort\n"
          "4) Quick Sort")
    choice = int(input("Enter your choice : "))  # Takes and Integer input
    assert choice in (1, 2, 3, 4), "Choice must be between 1 to 4"  # Prints an error if choice isn't in range 1 to 4
    return choice


def get_data_filename() -> str:
    """
    :return: str -> Returns the filename
    Prompts the user to input the filename from where the random numbers will be read.
    """
    while True:
        name = input("Enter the name of the csv file to read data : ")
        if os.path.exists(name):  # Checks whether the file exists or not
            return name  # Returns the name of the file if exits
        else:
            print("!!! File doesnt exists . !!!")  # Shows the output if file doesnt exists


def execute_algorithm(arr: list, algo: int) -> float:
    """

    :param arr: list -> A list containing the unsorted data
    :param algo: int : An integer denoting the algorithm to use
    :return: float -> Returns the execution time took to execute the algorithm
    """
    start = time.time()  # Starts the timer
    if algo == 1:
        bubbleSort(arr)
    elif algo == 2:
        insertionSort(arr)
    elif algo == 3:
        mergesort(arr)
    elif algo == 4:
        quicksort(arr)
    exec_time = time.time() - start  # Ends the timer by subtracting start from current time
    return exec_time


def get_results_filename() -> str:
    """
    :return: str -> Returns the filename
    Prompts the user to input the name of the file where results will be saved.
    """
    while True:
        results_file = input("Enter the name of the csv file to write results : ")
        if os.path.exists(results_file):  # If the file exists
            choice = input("File with same name already exists . Overwrite (y/n) : ")  # Asks to overwrite the file
            if choice in ("Y", "y", "Yes", "yes"):
                return results_file
        else:
            return results_file


def main():
    print("Welcome to Sorting Runtime Analysis")  # Prints the starting Message
    algo = choose_algo()  # Stores the algorithm to use .
    data_file = get_data_filename()  # Stores the name of the file the data is stored.
    results_file = get_results_filename()  # Stores the name of file the results will be saved.

    # Inputs how many lines to sort from results_file
    lines_to_sort = int(input("Enter how many lines of data you want to sort (1-200) : "))
    # Shows Error if lines_to_sort is less than 1 or greater than 200
    assert lines_to_sort in range(1, 201), "Enter number between 1 to 200"

    results_file = open(results_file, "w")  # Opens the results_file in write mode.
    with open(data_file, "r") as file:  # Opens the data_file in read more.
        reader = csv.reader(file)  # Creates a csv_reader to read the csv file

        # Converts the reader obj to list and then slices it the number of lines required to operate
        for row in list(reader)[:lines_to_sort]:
            exec_time = execute_algorithm(row, algo)

            results_file.write(f"{len(row)},{exec_time}\n")  # Writes the result in results file

            results_file.flush()
    results_file.close()  # Closes the results file


if __name__ == '__main__':
    main()
